# XBinary-Classifier
This is a repository that contains a package which is used to classify X-Ray binaries into high versus low mass category.
